###############################################################################################################################
Folder layout:

The folder containing the code for the Synthetic, ADNI, and, SEER experiments can be found in 'source.tar.gz'
The folder containing the code for the MIMIC-III experiments can be found in 'source_mimic.tar.gz'
    The MIMIC-III experiments are in a separate folder as the code is modified to handle 3 events


###############################################################################################################################
Data preprocessing:

The synthetic data, ADNI, and SEER do not require preprocessing before running the code (the code preprocesses on the spot)
The MIMIC-III data will need to be preprocessed. We used FIDDLE. The code is publicly available from the authors, but we have included the code in source_mimic/data_prep for convenience 
    See the readme in source_mimic/data_prep on which files to change to generate the features
    The command we used to run FIDDLE is included at the end of make_features.py for convenience
    Uncomment the applicable sections (specified within the file) of generate_labels.py to generate the labels


###############################################################################################################################
How to run the code:

1. In run.py, set the variables on lines 25 and 26 to the desired approach and dataset, respectively.
   The names of the approaches and datasets are given in lines 22 and 23.
   Note: hierarch-resid should only be run with the synthetic data, and heirarch-resid_semicomp should only be run with ADNI and SEER
         hierarch-resid_semicomp also works with competing risks
         hierarch-resid_semicomp3 should only be run with MIMIC-III (it was modified from hierarch-resid_semicomp for 3 events)
         simulation is the oracle and is only run with synthetic data

2. If the dataset is ADNI or SEER, set the variable on line 11 of get_data.py to where the data is stored
   If the dataset is MIMIC-III, set the variable on line 18 of get_data.py to where the preprocessed data is stored

3. Run run.py from the command line. No arguments are needed.
